# OPEN-MATH GENESIS 1.0.0 — Release Notes / 发布说明

## 中文

本版把上一版 86 项数学猜想图谱中的 44 项开放/争议对象进一步编译为 12 类证明基因组、12 类定义伏笔、10 类契约形状、7 类“无限”模式、12 类逃逸载体和 14 类证书。系统包含 V01–V16 结构验证、D81P 非自然语言载体、跨问题近邻、离线展示站点、Wheel、独立 PYZ、正式 Word 报告和逐文件摘要。

**边界：** `STRUCTURAL_PASS` 不等于外部猜想已被证明。

## English

This release compiles 44 open/disputed objects from the preceding 86-problem atlas into 12 proof genomes, 12 definition-origin traps, 10 contract shapes, 7 infinity modes, 12 escape carriers, and 14 certificate classes. It ships V01–V16 structural validation, a language-optional D81P carrier, cross-problem similarity, an offline dashboard, a Wheel, a standalone PYZ, a formal Word report, and per-file hashes.

**Boundary:** `STRUCTURAL_PASS` is not external theorem certification.
