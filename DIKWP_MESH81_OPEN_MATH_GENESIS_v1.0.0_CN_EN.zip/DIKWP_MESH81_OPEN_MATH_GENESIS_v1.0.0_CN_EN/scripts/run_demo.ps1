python -m open_math_genesis summary
python -m open_math_genesis show O01
python -m open_math_genesis validate examples/certificates/o01_open_bridge.json
