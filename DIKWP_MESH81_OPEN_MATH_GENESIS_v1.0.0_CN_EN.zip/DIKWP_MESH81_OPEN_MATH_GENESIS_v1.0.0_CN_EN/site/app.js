
const D=window.OMG81_DATA, T=D.taxonomy, P=D.problems, A=D.aggregates;
const $=s=>document.querySelector(s), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function metric(n,l){return `<div class="metric"><b>${n}</b><span>${l}</span></div>`}
$('#metrics').innerHTML=metric(A.count,'开放问题')+metric(Object.keys(A.genome_counts).length,'证明基因组')+metric(A.horizon_counts.H3||0,'重要局部闭合')+metric(A.horizon_counts.H4||0,'候选全局桥')+metric(0,'被本系统宣称外部解决');
for(const [c,v] of Object.entries(T.genomes)) $('#genome').insertAdjacentHTML('beforeend',`<option value="${c}">${c} ${v.cn}</option>`);
for(const s of [...new Set(P.map(x=>x.external_status_cn))]) $('#status').insertAdjacentHTML('beforeend',`<option>${s}</option>`);
for(const s of 'DIKWP') $('#position').insertAdjacentHTML('beforeend',`<option>${s}</option>`);
for(const [c,v] of Object.entries(T.closure_horizons)) $('#horizon').insertAdjacentHTML('beforeend',`<option value="${c}">${c} ${v.cn}</option>`);
function bars(target,obj,labeler,max){const m=max||Math.max(...Object.values(obj));$(target).innerHTML=Object.entries(obj).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="bar"><span>${esc(labeler(k))}</span><div class="track"><div class="fill" style="width:${v/m*100}%"></div></div><b>${v}</b></div>`).join('')}
bars('#genomeBars',A.genome_counts,k=>`${k} ${T.genomes[k].cn}`);bars('#burdenBars',A.average_burden,k=>k,5);
function card(p){const g=T.genomes[p.primary_genome], h=T.closure_horizons[p.closure_horizon];return `<article class="card">
<div><span class="id">${p.id}</span> · ${esc(p.name_en)}</div><h3>${esc(p.name_cn)}</h3>
<div class="tags"><span class="tag status">${esc(p.external_status_cn)}</span><span class="tag">${p.primary_genome} ${g.cn}</span><span class="tag">主位 ${p.primary_position}</span><span class="tag open">外部桥开放</span></div>
<div class="burden">${'DIKWP'.split('').map(k=>`<div>${k} ${p.burden_vector[k]}<i style="width:${p.burden_vector[k]*20}%"></i></div>`).join('')}</div>
<dl><dt>定义伏笔</dt><dd>${esc(p.definition_seed_cn)}</dd><dt>深层任务</dt><dd>${esc(p.bridge_mission_cn)}</dd><dt>闭合地平线</dt><dd>${p.closure_horizon} ${h.cn}</dd><dt>近邻对象</dt><dd>${p.nearest_neighbors.join(' · ')}</dd></dl>
<details class="details"><summary>展开基因组与证书</summary><p><b>逃逸载体：</b>${p.escape_carriers.map(x=>`${x} ${T.escape_carriers[x].cn}`).join('；')}</p><p><b>所需证书：</b>${p.required_certificates.map(x=>`${x} ${T.certificate_types[x].cn}`).join('；')}</p><p><b>仍缺桥：</b>${esc(p.missing_bridge_cn)}</p></details></article>`}
function render(){const q=$('#search').value.trim().toLowerCase(),g=$('#genome').value,s=$('#status').value,pos=$('#position').value,h=$('#horizon').value;const items=P.filter(p=>(!q||JSON.stringify(p).toLowerCase().includes(q))&&(!g||p.primary_genome===g)&&(!s||p.external_status_cn===s)&&(!pos||p.primary_position===pos)&&(!h||p.closure_horizon===h));$('#count').textContent=`显示 ${items.length} / ${P.length}`;$('#cards').innerHTML=items.map(card).join('')||'<p>无匹配对象。</p>'}
for(const e of ['search','genome','status','position','horizon']) $("#"+e).addEventListener(e==='search'?'input':'change',render);$('#reset').onclick=()=>{for(const e of ['search','genome','status','position','horizon']) $('#'+e).value='';render()};render();
