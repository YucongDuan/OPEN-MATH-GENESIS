
import json, tempfile, unittest
from pathlib import Path
from open_math_genesis.loader import problems, taxonomy, by_id, aggregates
from open_math_genesis.similarity import neighbors, score
from open_math_genesis.certificate import template, digest
from open_math_genesis.validate import validate
from open_math_genesis.native import export_certificate, validate as validate_native

class TestAtlas(unittest.TestCase):
    def test_count(self): self.assertEqual(len(problems()),44)
    def test_ids_unique(self): self.assertEqual(len({p['id'] for p in problems()}),44)
    def test_positions_core_only(self): self.assertTrue(all(p['primary_position'] in 'DIKWP' for p in problems()))
    def test_genomes(self): self.assertEqual(len(taxonomy()['genomes']),12)
    def test_every_genome_used(self): self.assertEqual(set(aggregates()['genome_counts']),set(taxonomy()['genomes']))
    def test_source_names(self): self.assertEqual(by_id('O01')['name_cn'],'黎曼猜想')
    def test_statuses(self): self.assertEqual(sum(aggregates()['status_counts'].values()),44)
    def test_neighbors(self): self.assertEqual(len(neighbors('O01',7)),7)
    def test_similarity_symmetric(self):
        a,b=by_id('O01'),by_id('O02'); self.assertEqual(score(a,b),score(b,a))
    def test_burdens(self): self.assertTrue(all(1<=p['burden_vector'][k]<=5 for p in problems() for k in 'DIKWP'))
    def test_external_open(self): self.assertTrue(all(p['native_status']=='OPEN_BRIDGE' for p in problems()))

class TestCertificates(unittest.TestCase):
    def complete(self,pid='O08'):
        c=template(pid)
        c['statement_snapshot'].update(domain='frozen',dimension_or_version='frozen',quantifiers='frozen',source_digest='a'*64)
        c['D'][0]['source']='source:a'
        for r in c['P']: r['procedure']='declared structural process'
        c['continuation_contract'].update(finite_stage='finite',successor_rule='append',invariant='preserve')
        c['external_bridge'].update(forward_compiler='declared',reverse_compiler='declared',fidelity_tests=['digest'])
        c['evidence']=[{'id':'e1','grade':'E2','digest':'b'*64,'independent':False}]
        c['declaration']['internal_status']='STRUCTURAL_CARRIER_COMPLETE'
        c['certificate_digest']=digest({k:v for k,v in c.items() if k!='certificate_digest'})
        return c
    def test_template_is_open(self): self.assertFalse(validate(template('O08'))['structural_pass'])
    def test_complete_structural_pass(self): self.assertTrue(validate(self.complete())['structural_pass'])
    def test_vector(self): self.assertEqual(validate(self.complete())['closure_vector'],'11111')
    def test_external_still_open(self): self.assertEqual(validate(self.complete())['external_bridge_status'],'OPEN')
    def test_boundary(self): self.assertIn('does not certify',validate(self.complete())['boundary'])
    def test_digest(self): self.assertTrue(validate(self.complete())['digest_ok'])
    def test_bad_digest(self):
        c=self.complete(); c['certificate_digest']='0'*64; self.assertFalse(validate(c)['digest_ok'])
    def test_no_truth_promotion(self):
        c=self.complete(); c['declaration']['external_status']='SOLVED'; c['continuation_contract']['status']='OPEN'; self.assertFalse([x for x in validate(c)['checks'] if x['code']=='V13'][0]['ok'])
    def test_missing_reverse(self):
        c=self.complete(); c['P']=[x for x in c['P'] if x['direction']!='reverse']; self.assertFalse(validate(c)['closure']['P'])
    def test_missing_w(self):
        c=self.complete(); c['W']=[]; self.assertFalse(validate(c)['closure']['W'])
    def test_escape_preservation(self):
        c=self.complete(); c['I']=[]; c['escape_ledger']=[]; self.assertFalse(validate(c)['closure']['I'])
    def test_native_roundtrip(self):
        c=self.complete(); r=validate_native(export_certificate(c)); self.assertTrue(r['valid']); self.assertEqual(r['closure_vector'],'11111')
    def test_native_rejects_header(self):
        with self.assertRaises(ValueError): validate_native('BAD|1\n')
    def test_native_paths(self):
        c=self.complete(); txt=export_certificate(c); self.assertIn('D>P|d001|p001',txt)

class TestTaxonomy(unittest.TestCase):
    def test_traps(self): self.assertEqual(len(taxonomy()['origin_traps']),12)
    def test_contracts(self): self.assertEqual(len(taxonomy()['contract_shapes']),10)
    def test_infinity(self): self.assertEqual(len(taxonomy()['infinity_modes']),7)
    def test_escapes(self): self.assertEqual(len(taxonomy()['escape_carriers']),12)
    def test_cert_types(self): self.assertEqual(len(taxonomy()['certificate_types']),14)
    def test_every_problem_has_mission(self): self.assertTrue(all(len(p['bridge_mission_cn'])>10 for p in problems()))
    def test_every_problem_has_escape(self): self.assertTrue(all(p['escape_carriers'] for p in problems()))
    def test_every_problem_has_cert(self): self.assertTrue(all(p['required_certificates'] for p in problems()))
    def test_infinity_open_successor_common(self): self.assertGreaterEqual(aggregates()['infinity_counts']['N1'],30)
    def test_replay_common(self): self.assertGreaterEqual(aggregates()['certificate_counts']['R12'],30)

if __name__=='__main__': unittest.main()
