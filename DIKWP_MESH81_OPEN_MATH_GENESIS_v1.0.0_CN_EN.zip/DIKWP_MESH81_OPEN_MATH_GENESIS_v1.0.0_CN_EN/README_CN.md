# DIKWP-MESH8.1 OPEN-MATH GENESIS

**未解数学对象生成、证明基因组与双向闭合开源系统**  
版本 `1.0.0` · 运行框架 `MESH81_DIKWP_NATIVE_CONTINUITY`

本系统把上一版 86 项图谱中的 **44 项外部仍未闭合对象**进一步重构为：

- 12 类证明基因组（它们只是 D/I/K/W/P 路径别名）；
- 12 类定义伏笔、10 类契约形状、7 类“无限”用法；
- 12 类逃逸载体、14 类最小证明证书；
- D/I/K/W/P 五元负担、闭合地平线与跨问题近邻网络；
- JSON 证书、非自然语言 `.d81p` 载体、16 项结构验证器；
- 可离线双击打开的交互展示站点。

## 最短运行

```bash
python -m open_math_genesis summary
python -m open_math_genesis list --genome G03
python -m open_math_genesis show O01
python -m open_math_genesis neighbors O06 --limit 8
python -m open_math_genesis init-certificate O08 --output goldbach.json
python -m open_math_genesis validate examples/certificates/o08_open_bridge.json
python -m open_math_genesis native-validate examples/native/o08_open_bridge.d81p
```

源码目录执行：

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -e .
omg81 summary
```

离线展示：直接打开 `site/index.html`。

## 正式报告与展示入口

- 正式 Word 报告：`reports/OPEN_MATH_GENESIS_44_OPEN_PROBLEMS_FORMAL_REPORT_CN.docx`
- 离线展示入口：双击根目录 `OPEN_DASHBOARD.html`，或直接打开 `site/index.html`。
- 生成图示：`docs/figures/`。

## 关键边界

`STRUCTURAL_PASS` 仅表示声明的 D/I/K/W/P 记录、路径、延续契约、逃逸账本和外部编译接口在结构上完整。它**不执行问题特定数学推导，也不把任何开放猜想认证为定理**。外部状态始终单独登记。

## 许可证

代码与系统文档：Apache-2.0。外部论文和既有报告保持各自版权与引用要求。
