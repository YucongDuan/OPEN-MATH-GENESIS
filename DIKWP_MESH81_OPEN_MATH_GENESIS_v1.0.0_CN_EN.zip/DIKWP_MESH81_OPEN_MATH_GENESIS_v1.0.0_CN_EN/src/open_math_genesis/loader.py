from __future__ import annotations
import json
from functools import lru_cache
from importlib.resources import files
from typing import Any

def _load(name: str) -> Any:
    return json.loads((files("open_math_genesis") / "data" / name).read_text(encoding="utf-8"))

@lru_cache(maxsize=1)
def problems() -> list[dict[str, Any]]:
    return _load("problems.json")

@lru_cache(maxsize=1)
def taxonomy() -> dict[str, Any]:
    return _load("taxonomy.json")

@lru_cache(maxsize=1)
def sources() -> list[dict[str, Any]]:
    return _load("sources.json")

@lru_cache(maxsize=1)
def aggregates() -> dict[str, Any]:
    return _load("aggregates.json")

def by_id(problem_id: str) -> dict[str, Any]:
    pid = problem_id.upper().strip()
    for item in problems():
        if item["id"] == pid:
            return item
    raise KeyError(f"unknown problem id: {problem_id}")
