from __future__ import annotations
import hashlib
import json
from copy import deepcopy
from typing import Any
from .loader import by_id, taxonomy

def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def digest(obj: Any) -> str:
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()

def template(problem_id: str) -> dict[str, Any]:
    p = by_id(problem_id)
    universal = "C01" in p.get("contract_shapes", [])
    d_payload = {
        "problem_id": p["id"], "name_cn": p["name_cn"],
        "statement_snapshot": "replace with exact formal statement and source digest"
    }
    i_records = [
        {"id": f"i{n:03d}", "payload": code, "preserved": True}
        for n, code in enumerate(p.get("escape_carriers", []), 1)
    ]
    cert = {
        "schema_version": "1.0.0",
        "runtime": "MESH81_DIKWP_NATIVE_CONTINUITY",
        "problem_id": p["id"],
        "claim_scope": "universal" if universal else "problem-specific",
        "statement_snapshot": {
            "title_cn": p["name_cn"], "title_en": p["name_en"],
            "domain": "EXPLICITLY_FREEZE_DOMAIN",
            "dimension_or_version": "EXPLICITLY_FREEZE_DIMENSION_OR_VERSION",
            "quantifiers": "EXPLICITLY_FREEZE_QUANTIFIERS",
            "source_digest": "PENDING"
        },
        "D": [{"id": "d001", "payload": d_payload, "source": "source-ledger:PENDING"}],
        "I": i_records or [{"id":"i001","payload":"OPEN_DIFFERENCE","preserved":True}],
        "K": [{"id": "k001", "payload": "candidate complete semantic carrier", "covers": []}],
        "W": [{"id": "w001", "payload": "admissible proof world and evidence rules", "declared": True}],
        "P": [
            {"id":"p001","direction":"forward","input_ids":[],"output_ids":["k001"],"procedure":"PENDING","evidence_refs":[]},
            {"id":"p002","direction":"reverse","input_ids":["k001"],"output_ids":[],"procedure":"PENDING","evidence_refs":[]}
        ],
        "paths": [],
        "continuation_contract": {
            "required": universal,
            "status": "OPEN",
            "finite_stage": "PENDING",
            "successor_rule": "PENDING",
            "invariant": "PENDING",
            "open_residue": p["missing_bridge_cn"]
        },
        "escape_ledger": [
            {"code": code, "status": "OPEN", "evidence_refs": []}
            for code in p.get("escape_carriers", [])
        ],
        "external_bridge": {
            "target_system": "EXTERNAL_MATHEMATICS",
            "status": "OPEN",
            "forward_compiler": "PENDING",
            "reverse_compiler": "PENDING",
            "fidelity_tests": []
        },
        "evidence": [],
        "declaration": {
            "internal_status": "DRAFT",
            "external_status": p["external_status_cn"],
            "no_truth_promotion": True,
            "boundary": "Structural validation is not external theorem certification."
        }
    }
    # Fill references only; no claim is made closed.
    all_non_k = [x["id"] for key in ("D","I","W","P") for x in cert[key]]
    cert["K"][0]["covers"] = all_non_k
    forward_inputs = [x["id"] for key in ("D","I","W") for x in cert[key]]
    cert["P"][0]["input_ids"] = forward_inputs
    cert["P"][1]["output_ids"] = forward_inputs
    rec_type = {r["id"]: key for key in "DIKWP" for r in cert[key]}
    for src in forward_inputs:
        cert["paths"].append({"from":src,"to":"p001","type":f"{rec_type[src]}>P"})
    cert["paths"].append({"from":"p001","to":"k001","type":"P>K"})
    cert["paths"].append({"from":"k001","to":"p002","type":"K>P"})
    for dst in forward_inputs:
        cert["paths"].append({"from":"p002","to":dst,"type":f"P>{rec_type[dst]}"})
    cert["certificate_digest"] = digest({k:v for k,v in cert.items() if k != "certificate_digest"})
    return cert
