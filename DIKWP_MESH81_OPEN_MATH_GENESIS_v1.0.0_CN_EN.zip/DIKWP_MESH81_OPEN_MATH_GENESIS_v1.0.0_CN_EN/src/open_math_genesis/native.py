from __future__ import annotations
import binascii
import json
import re
from pathlib import Path
from typing import Any

HEADER = "D81P|1"
REC_RE = re.compile(r"^(D|I|K|W|P)\|([0-9a-zA-Z_.-]+)\|([01])\|([^|]*)\|([^|]*)\|([0-9a-f]*)$")
PATH_RE = re.compile(r"^(D|I|K|W|P)>(D|I|K|W|P)\|([0-9a-zA-Z_.-]+)\|([0-9a-zA-Z_.-]+)$")

def _hex(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8").hex()

def export_certificate(c: dict[str,Any]) -> str:
    lines = [HEADER]
    for kind in "DIKWP":
        for r in c.get(kind,[]):
            if kind == "P":
                inp = ','.join(r.get("input_ids",[]))
                out = ','.join(r.get("output_ids",[]))
                payload = {"direction":r.get("direction"),"procedure":r.get("procedure"),"evidence_refs":r.get("evidence_refs",[])}
                lines.append(f"P|{r['id']}|1|{inp}|{out}|{_hex(payload)}")
            elif kind == "K":
                covers = ','.join(r.get("covers",[]))
                lines.append(f"K|{r['id']}|1|{covers}||{_hex(r.get('payload'))}")
            else:
                lines.append(f"{kind}|{r['id']}|1|||{_hex(r.get('payload'))}")
    for p in c.get("paths",[]):
        lines.append(f"{p['type']}|{p['from']}|{p['to']}")
    return '\n'.join(lines) + '\n'

def parse(text: str) -> dict[str,Any]:
    raw = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not raw or raw[0] != HEADER:
        raise ValueError("missing D81P|1 header")
    records, paths = [], []
    for n, line in enumerate(raw[1:],2):
        m = REC_RE.match(line)
        if m:
            kind,rid,given,left,right,payload_hex = m.groups()
            try:
                payload = json.loads(bytes.fromhex(payload_hex).decode("utf-8")) if payload_hex else None
            except Exception as exc:
                raise ValueError(f"line {n}: invalid payload hex/json: {exc}")
            records.append({"kind":kind,"id":rid,"given":given=="1","left":[x for x in left.split(',') if x],"right":[x for x in right.split(',') if x],"payload":payload})
            continue
        m = PATH_RE.match(line)
        if m:
            a,b,src,dst = m.groups()
            paths.append({"type":f"{a}>{b}","from":src,"to":dst})
            continue
        raise ValueError(f"line {n}: invalid native statement")
    return {"records":records,"paths":paths}

def validate(text: str) -> dict[str,Any]:
    obj = parse(text)
    ids, duplicates = {}, []
    for r in obj["records"]:
        if r["id"] in ids: duplicates.append(r["id"])
        else: ids[r["id"]] = r["kind"]
    refs = []
    for r in obj["records"]:
        refs.extend(r["left"]); refs.extend(r["right"])
    path_ok = all(p["from"] in ids and p["to"] in ids and p["type"] == f"{ids[p['from']]}>{ids[p['to']]}" for p in obj["paths"])
    refs_ok = all(x in ids for x in refs)
    bykind = {k:[r for r in obj["records"] if r["kind"]==k and r["given"]] for k in "DIKWP"}
    forward = any(r["kind"]=="P" and isinstance(r["payload"],dict) and r["payload"].get("direction")=="forward" for r in obj["records"])
    reverse = any(r["kind"]=="P" and isinstance(r["payload"],dict) and r["payload"].get("direction")=="reverse" for r in obj["records"])
    closure = {"D":bool(bykind['D']),"I":bool(bykind['I']),"K":bool(bykind['K']),"W":bool(bykind['W']),"P":bool(bykind['P']) and forward and reverse and path_ok}
    return {
        "valid": not duplicates and refs_ok and path_ok and all(bykind[k] for k in "DIKWP"),
        "record_count": len(obj["records"]), "path_count":len(obj["paths"]),
        "duplicates":duplicates,"refs_ok":refs_ok,"paths_ok":path_ok,
        "closure":closure,"closure_vector":''.join('1' if closure[k] else '0' for k in "DIKWP")
    }

def validate_file(path: str | Path) -> dict[str,Any]:
    return validate(Path(path).read_text(encoding="utf-8"))
