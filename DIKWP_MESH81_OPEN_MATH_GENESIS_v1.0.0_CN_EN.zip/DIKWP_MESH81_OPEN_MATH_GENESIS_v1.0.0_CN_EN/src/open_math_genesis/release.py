from __future__ import annotations
import hashlib
from pathlib import Path

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def verify_manifest(root: str | Path) -> dict:
    root=Path(root)
    manifest=root/'MANIFEST.sha256'
    checked=failed=0; details=[]
    if not manifest.exists():
        return {"ok":False,"reason":"MANIFEST.sha256 missing"}
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        expected, rel=line.split('  ',1)
        path=root/rel
        actual=sha256(path) if path.exists() else None
        ok=actual==expected
        checked+=1; failed+=0 if ok else 1
        details.append({"path":rel,"ok":ok,"expected":expected,"actual":actual})
    return {"ok":failed==0,"checked":checked,"failed":failed,"details":details}
