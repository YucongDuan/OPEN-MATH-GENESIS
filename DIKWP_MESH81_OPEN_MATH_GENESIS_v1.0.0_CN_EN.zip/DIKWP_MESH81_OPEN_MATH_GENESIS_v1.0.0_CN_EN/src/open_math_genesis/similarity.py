from __future__ import annotations
import math
from typing import Any
from .loader import problems, by_id

def feature_set(p: dict[str, Any]) -> set[str]:
    return {
        p["primary_genome"], *p.get("secondary_genomes", []),
        *p.get("contract_shapes", []), *p.get("infinity_modes", []),
        *p.get("escape_carriers", []), *p.get("required_certificates", [])
    }

def score(a: dict[str, Any], b: dict[str, Any]) -> float:
    fa, fb = feature_set(a), feature_set(b)
    j = len(fa & fb) / max(1, len(fa | fb))
    va, vb = a["burden_vector"], b["burden_vector"]
    dot = sum(va[k]*vb[k] for k in "DIKWP")
    na = math.sqrt(sum(va[k]**2 for k in "DIKWP"))
    nb = math.sqrt(sum(vb[k]**2 for k in "DIKWP"))
    cosine = dot / max(1e-9, na*nb)
    genome = 1.0 if a["primary_genome"] == b["primary_genome"] else 0.0
    return round(0.55*j + 0.30*cosine + 0.15*genome, 6)

def neighbors(problem_id: str, limit: int = 5) -> list[dict[str, Any]]:
    p = by_id(problem_id)
    ranked = sorted(
        ({"id": q["id"], "name_cn": q["name_cn"], "score": score(p, q)}
         for q in problems() if q["id"] != p["id"]),
        key=lambda x: (x["score"], x["id"]), reverse=True
    )
    return ranked[:max(1, limit)]
