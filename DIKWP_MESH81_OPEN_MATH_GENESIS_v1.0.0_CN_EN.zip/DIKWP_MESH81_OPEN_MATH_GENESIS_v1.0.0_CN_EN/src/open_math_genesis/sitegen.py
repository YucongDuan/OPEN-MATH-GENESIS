from __future__ import annotations
import json
import shutil
from importlib.resources import files
from pathlib import Path
from .loader import problems, taxonomy, aggregates

def build_site(output: str | Path) -> Path:
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    template = files("open_math_genesis") / "web"
    for name in ("index.html","styles.css","app.js"):
        (out/name).write_bytes((template/name).read_bytes())
    payload = "window.OMG81_DATA=" + json.dumps({"problems":problems(),"taxonomy":taxonomy(),"aggregates":aggregates()}, ensure_ascii=False, separators=(",", ":")) + ";\n"
    (out/"data.js").write_text(payload, encoding="utf-8")
    return out
