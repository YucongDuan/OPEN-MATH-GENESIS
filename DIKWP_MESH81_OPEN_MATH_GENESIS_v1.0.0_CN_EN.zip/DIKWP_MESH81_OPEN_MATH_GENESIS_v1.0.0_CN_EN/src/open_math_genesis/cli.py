from __future__ import annotations
import argparse
import csv
import json
import sys
from pathlib import Path
from . import __version__
from .loader import problems, taxonomy, aggregates, by_id
from .similarity import neighbors
from .certificate import template
from .validate import validate_file
from .native import export_certificate, validate_file as validate_native_file
from .sitegen import build_site
from .release import verify_manifest

def dump(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))

def cmd_summary(_):
    a=aggregates(); t=taxonomy()
    print(f"DIKWP-MESH8.1 OPEN-MATH GENESIS v{__version__}")
    print(f"Open objects: {a['count']}")
    print("External statuses:", a['status_counts'])
    print("Primary genomes:")
    for code,count in sorted(a['genome_counts'].items()):
        print(f"  {code} {t['genomes'][code]['cn']}: {count}")
    print("Average D/I/K/W/P burden:", a['average_burden'])
    print("Boundary: internal structural closure is not external theorem certification.")

def cmd_list(args):
    items=problems()
    if args.genome: items=[p for p in items if p['primary_genome']==args.genome]
    if args.status: items=[p for p in items if p['external_status_cn']==args.status]
    if args.position: items=[p for p in items if p['primary_position']==args.position]
    for p in items:
        print(f"{p['id']}	{p['name_cn']}	{p['external_status_cn']}	{p['primary_genome']}	{p['primary_position']}")

def cmd_show(args): dump(by_id(args.problem_id))
def cmd_neighbors(args): dump(neighbors(args.problem_id,args.limit))
def cmd_contract(args):
    p=by_id(args.problem_id)
    dump({"problem_id":p['id'],"mission":p['bridge_mission_cn'],"required_certificates":p['required_certificates'],"escape_carriers":p['escape_carriers'],"external_boundary":"open"})
def cmd_init(args):
    obj=template(args.problem_id); out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8'); print(out)
def cmd_validate(args): dump(validate_file(args.path))
def cmd_native_export(args):
    c=json.loads(Path(args.path).read_text(encoding='utf-8')); out=Path(args.output); out.write_text(export_certificate(c),encoding='utf-8'); print(out)
def cmd_native_validate(args): dump(validate_native_file(args.path))
def cmd_build_site(args): print(build_site(args.output))
def cmd_export(args):
    out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True)
    if args.format=='json': out.write_text(json.dumps(problems(),ensure_ascii=False,indent=2),encoding='utf-8')
    else:
        fields=['id','name_cn','name_en','external_status_cn','primary_position','primary_genome','closure_horizon','bridge_difficulty_index','transfer_leverage_index']
        with out.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader();
            for p in problems(): w.writerow({k:p.get(k) for k in fields})
    print(out)
def cmd_verify_release(args): dump(verify_manifest(args.root))

def build_parser():
    p=argparse.ArgumentParser(prog='omg81',description='DIKWP-MESH8.1 Open Math Genesis')
    p.add_argument('--version',action='version',version=__version__)
    sp=p.add_subparsers(dest='cmd',required=True)
    x=sp.add_parser('summary'); x.set_defaults(func=cmd_summary)
    x=sp.add_parser('list'); x.add_argument('--genome'); x.add_argument('--status'); x.add_argument('--position',choices=list('DIKWP')); x.set_defaults(func=cmd_list)
    x=sp.add_parser('show'); x.add_argument('problem_id'); x.set_defaults(func=cmd_show)
    x=sp.add_parser('neighbors'); x.add_argument('problem_id'); x.add_argument('--limit',type=int,default=5); x.set_defaults(func=cmd_neighbors)
    x=sp.add_parser('contract'); x.add_argument('problem_id'); x.set_defaults(func=cmd_contract)
    x=sp.add_parser('init-certificate'); x.add_argument('problem_id'); x.add_argument('--output',required=True); x.set_defaults(func=cmd_init)
    x=sp.add_parser('validate'); x.add_argument('path'); x.set_defaults(func=cmd_validate)
    x=sp.add_parser('native-export'); x.add_argument('path'); x.add_argument('--output',required=True); x.set_defaults(func=cmd_native_export)
    x=sp.add_parser('native-validate'); x.add_argument('path'); x.set_defaults(func=cmd_native_validate)
    x=sp.add_parser('build-site'); x.add_argument('--output',required=True); x.set_defaults(func=cmd_build_site)
    x=sp.add_parser('export'); x.add_argument('--format',choices=['json','csv'],default='json'); x.add_argument('--output',required=True); x.set_defaults(func=cmd_export)
    x=sp.add_parser('verify-release'); x.add_argument('--root',default='.'); x.set_defaults(func=cmd_verify_release)
    return p

def main(argv=None):
    args=build_parser().parse_args(argv)
    try: args.func(args)
    except Exception as exc:
        print(f"ERROR: {exc}",file=sys.stderr); return 2
    return 0

if __name__=='__main__': raise SystemExit(main())
