from __future__ import annotations
import hashlib
import json
from pathlib import Path
from typing import Any, Callable
from .loader import by_id
from .certificate import digest

REQUIRED_TOP = {"schema_version","runtime","problem_id","claim_scope","statement_snapshot","D","I","K","W","P","paths","continuation_contract","escape_ledger","external_bridge","evidence","declaration"}

def _result(code: str, name: str, ok: bool, detail: str) -> dict[str, Any]:
    return {"code":code,"name":name,"ok":bool(ok),"detail":detail}

def _all_records(c: dict[str,Any]) -> tuple[dict[str,str], list[str]]:
    types, duplicates = {}, []
    for kind in "DIKWP":
        for rec in c.get(kind, []):
            rid = rec.get("id")
            if rid in types: duplicates.append(rid)
            elif rid: types[rid] = kind
    return types, duplicates

def validate(c: dict[str, Any]) -> dict[str, Any]:
    checks: list[dict[str,Any]] = []
    missing = sorted(REQUIRED_TOP - set(c))
    checks.append(_result("V01","核心结构与有限载体", not missing and all(isinstance(c.get(k),list) for k in "DIKWP"), f"missing={missing}"))
    try:
        problem = by_id(str(c.get("problem_id","")))
        known = True
    except Exception as exc:
        problem, known = None, False
    checks.append(_result("V02","问题对象登记", known, "known problem" if known else "problem id not in 44-object atlas"))

    snap = c.get("statement_snapshot", {})
    frozen = all(snap.get(k) and "PENDING" not in str(snap.get(k)) and "EXPLICITLY" not in str(snap.get(k)) for k in ("domain","dimension_or_version","quantifiers","source_digest"))
    checks.append(_result("V03","陈述、域、维数/版本与量词冻结", frozen, "frozen" if frozen else "one or more seams remain placeholders"))

    types, duplicates = _all_records(c)
    ids_ok = bool(types) and not duplicates and all(isinstance(c.get(k),list) for k in "DIKWP")
    checks.append(_result("V04","D/I/K/W/P 记录唯一且可引用", ids_ok, f"records={len(types)}, duplicates={duplicates}"))

    d_ok = bool(c.get("D")) and all(r.get("source") and r.get("payload") is not None for r in c.get("D",[]))
    checks.append(_result("V05","D 给出来源可追溯", d_ok, "all D records sourced" if d_ok else "missing D source or payload"))

    expected_escape = set(problem.get("escape_carriers",[]) if problem else [])
    represented_i = {str(r.get("payload")) for r in c.get("I",[])}
    ledger_codes = {str(x.get("code")) for x in c.get("escape_ledger",[])}
    i_ok = bool(c.get("I")) and expected_escape.issubset(represented_i | ledger_codes) and all(r.get("preserved") is True for r in c.get("I",[]))
    checks.append(_result("V06","I 差异与逃逸载体不被删除", i_ok, f"expected={sorted(expected_escape)}, represented={sorted(represented_i|ledger_codes)}"))

    non_k = {rid for rid,t in types.items() if t != "K"}
    k_covers = set().union(*(set(r.get("covers",[])) for r in c.get("K",[]))) if c.get("K") else set()
    k_ok = bool(c.get("K")) and non_k.issubset(k_covers)
    checks.append(_result("V07","K 覆盖声明完整", k_ok, f"uncovered={sorted(non_k-k_covers)}"))

    w_ok = bool(c.get("W")) and all(r.get("declared") is True and r.get("payload") for r in c.get("W",[]))
    checks.append(_result("V08","W 世界与证据规则显式", w_ok, "declared" if w_ok else "missing explicit W"))

    forwards = [r for r in c.get("P",[]) if r.get("direction") == "forward"]
    reverses = [r for r in c.get("P",[]) if r.get("direction") == "reverse"]
    f_ok = bool(forwards) and all(r.get("input_ids") and r.get("output_ids") and r.get("procedure") and r.get("procedure") != "PENDING" for r in forwards)
    r_ok = bool(reverses) and all(r.get("input_ids") and r.get("output_ids") and r.get("procedure") and r.get("procedure") != "PENDING" for r in reverses)
    checks.append(_result("V09","正向 P 已给出", f_ok, f"forward_count={len(forwards)}"))
    checks.append(_result("V10","反向 P 已给出", r_ok, f"reverse_count={len(reverses)}"))

    paths = c.get("paths",[])
    path_ok = bool(paths) and all(x.get("from") in types and x.get("to") in types and x.get("type") == f"{types[x.get('from')]}>{types[x.get('to')]}" for x in paths)
    checks.append(_result("V11","二十五类路径引用与类型一致", path_ok, f"paths={len(paths)}"))

    cont = c.get("continuation_contract",{})
    required = bool(problem and "N1" in problem.get("infinity_modes",[])) or c.get("claim_scope") == "universal"
    cont_present = all(cont.get(k) and cont.get(k) != "PENDING" for k in ("finite_stage","successor_rule","invariant")) if required else True
    checks.append(_result("V12","开放延续契约已登记", cont_present, "required" if required else "not required"))

    no_promotion = not (required and cont.get("status") != "CLOSED" and c.get("declaration",{}).get("external_status") in {"SOLVED","已解决","CLOSED"})
    checks.append(_result("V13","禁止有限验证升级为全称完成", no_promotion, f"continuation={cont.get('status')}, external={c.get('declaration',{}).get('external_status')}"))

    ext = c.get("external_bridge",{})
    ext_declared = all(ext.get(k) and ext.get(k) != "PENDING" for k in ("target_system","forward_compiler","reverse_compiler")) and isinstance(ext.get("fidelity_tests"),list)
    checks.append(_result("V14","外部双向编译桥已声明", ext_declared, f"status={ext.get('status')}"))

    ev = c.get("evidence",[])
    evidence_ok = bool(ev) and all(e.get("id") and e.get("grade") in {"E0","E1","E2","E3","E4"} and e.get("digest") and isinstance(e.get("independent"),bool) for e in ev)
    checks.append(_result("V15","证据等级与独立复算账本", evidence_ok, f"evidence_count={len(ev)}"))

    decl = c.get("declaration",{})
    boundary_ok = decl.get("no_truth_promotion") is True and bool(decl.get("boundary")) and decl.get("internal_status") not in {"EXTERNAL_THEOREM","SOLVED_EXTERNALLY"}
    checks.append(_result("V16","内部闭合不得冒充外部定理", boundary_ok, str(decl.get("boundary","missing"))))

    structural_pass = all(x["ok"] for x in checks)
    closure = {
        "D": d_ok,
        "I": i_ok,
        "K": k_ok,
        "W": w_ok,
        "P": f_ok and r_ok and path_ok,
    }
    vector = ''.join('1' if closure[k] else '0' for k in "DIKWP")
    ext_status = c.get("external_bridge",{}).get("status","OPEN")
    verdict = "STRUCTURAL_PASS" if structural_pass else "STRUCTURAL_OPEN"
    if structural_pass:
        verdict += "_EXTERNAL_" + str(ext_status).upper()
    core = {k:v for k,v in c.items() if k != "certificate_digest"}
    declared_digest = c.get("certificate_digest")
    computed_digest = digest(core)
    digest_ok = declared_digest in (None, computed_digest)
    return {
        "problem_id": c.get("problem_id"),
        "structural_pass": structural_pass,
        "closure": closure,
        "closure_vector": vector,
        "external_bridge_status": ext_status,
        "verdict": verdict,
        "digest_ok": digest_ok,
        "declared_digest": declared_digest,
        "computed_digest": computed_digest,
        "checks": checks,
        "boundary": "A structural PASS validates declared interfaces only; it does not certify an open conjecture as true."
    }

def validate_file(path: str | Path) -> dict[str,Any]:
    p = Path(path)
    return validate(json.loads(p.read_text(encoding="utf-8")))
