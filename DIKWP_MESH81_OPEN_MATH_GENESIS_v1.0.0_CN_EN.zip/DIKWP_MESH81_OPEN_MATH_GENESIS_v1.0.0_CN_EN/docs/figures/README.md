# Generated figures / 生成图示

All PNG files in this directory were generated for OPEN-MATH GENESIS 1.0.0. They visualize the D/I/K/W/P core, proof-genome distribution, burden profile, infinity modes, escape carriers, closure horizons, transfer leverage, cross-problem network, proof-genesis cycle, and system architecture.
