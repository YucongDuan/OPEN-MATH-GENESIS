# OPEN-MATH GENESIS 1.0.0 — System Specification / 系统规范

## 1. Semantic authority / 语义权
Only D, I, K, W, and P have runtime semantic authority. Genome, trap, contract, escape, horizon, and certificate codes are indexes derived from those five positions.

仅 D、I、K、W、P 具有运行时语义权。基因组、伏笔、契约、逃逸、地平线和证书代码均为五位置派生索引。

## 2. Proof genesis / 证明生成
A proof carrier must expose finite D records, preserve all relevant I records, assemble K with declared coverage, state W, and provide forward and reverse P. Universal claims over open domains additionally require a continuation contract. External closure requires a separate bidirectional compiler and independent replay.

## 3. Validation boundary / 验证边界
The validator checks structure, references, explicit seams, declared evidence grades, and anti-promotion rules. It cannot determine whether a mathematical argument inside a payload is correct.

## 4. Native carrier / 原生载体
`.d81p` uses only D/I/K/W/P record kinds, record identifiers, directed paths, and opaque hexadecimal payloads. Natural language is optional metadata outside the native core.
