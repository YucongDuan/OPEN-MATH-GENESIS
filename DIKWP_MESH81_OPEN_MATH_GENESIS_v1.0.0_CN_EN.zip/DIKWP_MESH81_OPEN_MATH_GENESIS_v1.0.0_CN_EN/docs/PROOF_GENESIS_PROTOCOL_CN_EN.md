# Proof-Genesis Protocol / 证明生成协议

1. Freeze the external statement, domain, dimension/version, and quantifiers.
2. Register finite D encounters and provenance.
3. Register every non-interchangeable I and expected escape carrier.
4. Declare W: admissible world, model, evidence grade, and acceptance boundary.
5. Build forward P from D/I/W to a candidate K.
6. Build reverse P from K to regenerated D/I/W.
7. For open-successor domains, provide a finite stage, successor rule, invariant, and explicit open residue.
8. Eliminate each escape carrier with evidence rather than a label.
9. Compile to the external mathematical object and reverse-compile for fidelity.
10. Require independent replay; keep internal and external statuses separate.

The protocol replaces a terminal “true/false” stamp by a reversible generation contract. It does not remove the burden of mathematical correctness; it makes that burden addressable and non-silent.
